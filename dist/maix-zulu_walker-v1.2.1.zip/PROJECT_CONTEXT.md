# Zulu-Walker — Project Context

> 完整项目参考，供 Agent 快速加载上下文，避免重复探索。
> 最后更新: 2026-07-28

---

## 1. 项目概述

基于 **MaixCAM2 (Axera AX630C)** 的 **YOLO11n 钢珠检测小车**，预留视觉循迹能力，面向 **2026 全国大学生电子设计竞赛**（赛题未发布，目前按通用机器人平台预研）。

- **平台**: `maixcam2` (Axera AX630C, 2×A53@1.2GHz, 3.2TOPS NPU, 4GB RAM)
- **通信**: UART `/dev/ttyS3` @ 115200, 协议 v2.1 (SOF+CRC16)
- **AI**: `maix.nn` YOLO11 模型 (`/root/models/steelball_640.mud`)
- **摄像头**: 板载 8MP MIPI CSI (640×640 RGB888)
- **显示**: 板载 2.4" 640×480 触摸屏 (可选关闭)

---

## 2. 目录结构

```
F:\zw\Zulu-Walker/
├── app/                              # 应用层
│   ├── main.py                       # 入口，初始化 Machine → ModuleManager → Coordinator
│   ├── coordinator.py                # LineFollowCoordinator：桥接视觉→UART，心跳协议
│   ├── mission_state_machine.py      # 34 状态竞赛任务状态机 (931 行)
│   ├── line_follow_sm.py             # 5 状态循迹状态机 (简版)
│   └── events.py                     # FrameReady, ServoData 事件
│
├── framework/                        # 框架层
│   ├── event_bus.py                  # EventBus — 类型键控发布/订阅 (RLock)
│   ├── module_manager.py             # ModuleManager — 模块生命周期 + 主循环 @60Hz
│   ├── visual_state_machine.py       # VisualStateMachine — 5 状态视觉追踪 (IDLE/SEARCH/TRACKING/RECOVERY/FAIL)
│   ├── log.py                        # fw_log 辅助
│   ├── state_machine/                # 通用状态机引擎
│   │   ├── base.py                   # BaseStateMachine (412 行) — RLock, 事件+条件转换, run_to_completion
│   │   └── bridge.py                 # StateActionBridge — 声明式状态↔动作绑定
│   ├── hal/
│   │   ├── machine.py                # Machine.create(config_path) — DI 容器
│   │   ├── camera_hub.py             # CameraHub — 多相机注册表 (单例)
│   │   ├── interface/                # Protocol 定义
│   │   │   ├── camera.py             # Camera: read(), fps, set(), release()
│   │   │   ├── display.py            # Display: show(), close()
│   │   │   ├── uart.py               # Uart: send/receive, start_receiver(callback)
│   │   │   └── ai.py                 # AIInference: detect(), classify(), add/switch/remove 模型
│   │   └── platforms/
│   │       ├── maixcam2/             # 生产平台 — maix.* API
│   │       │   ├── camera.py         # MaixCam2Camera (maix.camera, image2cv)
│   │       │   ├── display.py        # MaixCam2Display (maix.display)
│   │       │   ├── uart.py           # MaixCam2Uart (maix.peripheral.uart, 回调接收)
│   │       │   └── ai.py             # MaixCam2AI (maix.nn, YOLO11/Classifier/HandLandmarks, 434 行)
│   │       ├── linux/                # 旧开发平台 — OpenCV + pyserial
│   │       │   ├── camera.py         # LinuxCamera (subprocess 预热, 自动重连)
│   │       │   ├── display.py        # LinuxDisplay (cv2.imshow)
│   │       │   ├── uart.py           # LinuxUart (pyserial, 轮询线程)
│   │       │   └── ai.py             # LinuxAI (存根, 无 NPU)
│   │       └── mock/                 # 测试/开发 — 模拟实例
│   │
│   └── state_machine/engine...       # (已在 state_machine/ 中)
│
├── modules/
│   ├── zw_opencv_module/             # 视觉模块
│   │   ├── __init__.py               # 生命周期 (init/start/loop/stop)
│   │   ├── vision_manager.py         # VisionManager — 管道管理, 后台处理线程, 显示帧
│   │   ├── pipeline_camera.py         # PipelineCamera — 单摄像头管道, image2cv→任务
│   │   ├── task_manager.py           # TaskManager — 串行任务执行, 上下文传递
│   │   ├── camera_stream.py          # 备选流方案
│   │   ├── config/
│   │   │   └── vision_config.yaml    # 管道配置 (cam_main, ai_inference 启用, line_follow 禁用)
│   │   ├── detectors/                # 底层检测器实现
│   │   │   ├── line_detector/        # 黑线检测
│   │   │   ├── cargo_detector/       # 物料块检测 (已被 app.yaml exclude)
│   │   │   ├── circle_target_detector/ (已被 exclude)
│   │   │   └── ring_detector/        # (已被 exclude)
│   │   └── processors/               # 处理器层
│   │       ├── base.py               # Processor ABC, VisionResult, ColorTrackable
│   │       ├── registry.py           # @register_processor 装饰器
│   │       ├── line_follow_processor.py  # 黑线处理 (实际在用)
│   │       ├── ai_inference_processor.py (已被 app.yaml exclude)
│   │       ├── qr_processor.py       # (已被 exclude)
│   │       ├── cargo_processor.py    # (已被 exclude)
│   │       ├── circle_target_processor.py (已被 exclude)
│   │       └── ring_discovery_processor.py (已被 exclude)
│   │
│   └── zw_uart_module/               # UART 通信模块
│       ├── __init__.py               # 生命周期
│       ├── uart_driver.py            # STM32UartInterface + FrameParser 状态机 (428 行)
│       ├── protocol.py               # 协议 v2.1 定义 (CRC16-CCITT, 帧构建/解析)
│       ├── events.py                 # HeartbeatEvent, EmergencyStopEvent
│       └── exceptions.py             # UartError, InvalidFrameError 等
│
├── utils/
│   ├── log_util.py                   # log_print, LoggerFactory, UARTModuleLogger, DataPipelineLogger
│   ├── debug_console.py              # DebugConsole — Rich TUI 单例 (205 行)
│   ├── console_capture.py            # ConsoleCapture — stdout 替换/重定向
│   ├── cpu_affinity.py               # CPU 亲和性绑定 (仅 Linux)
│   ├── camera_misc_util.py           # CameraMiscUtil — V4L2 设备发现
│   ├── focal_distance_util.py        # FocalDistanceCalculator, CameraIntrinsics
│   └── point.py                      # Point 2D, get_angle, get_cos_angle
│
├── MaixPy-main/                      # 上游 Sipeed MaixPy 固件源码 (参考, 只读)
│   ├── maix/                         # Python 层 — maix.__init__, maix.v1/, sensevoice.py
│   ├── components/maix/include/      # C++ 头: maixpy.hpp, convert_image.hpp
│   ├── components/maix/src/          # C++ 源: maixpy.cpp (pybind11 绑定)
│   ├── components/maix/gen_api*.py   # API 绑定代码生成器
│   ├── projects/                     # 官方示例: usb_video_camera, app_vlm, app_yolo_obb...
│   ├── examples/                     # maixpy_v1/sensor.py, lcd.py, vision/video/
│   ├── configs/                      # 平台编译配置 (.mk)
│   ├── main/                         # 固件入口 (main.cpp)
│   ├── docs/doc/zh/                  # 中文 API 文档 (vision/, video/...)
│   └── .github/workflows/            # CI 构建脚本
│
├── project_config.yaml               # 平台配置 (maixcam2, 640×640, yolo11n)
├── app.yaml                          # MaixPy 应用打包清单
├── run.py                            # 启动器 (main / debug 模式)
├── main.py                           # MaixPy 应用入口 (8 行, 转发到 app.main.main)
├── requirements.txt                  # numpy, pyyaml, rich, pyzbar
└── requirements-linux.txt            # pyserial, opencv-contrib-python (仅 Linux 调试)
```

---

## 3. 架构概览

### 3.1 分层架构

```
┌─────────────────────────────────────────────────────────────┐
│  app/main.py                                                 │
│  ├─ LineFollowCoordinator (桥接视觉→UART)                    │
│  ├─ MissionStateMachine (34 状态, 竞赛逻辑)                   │
│  └─ LineFollowStateMachine (5 状态, 简单循迹)                 │
├─────────────────────────────────────────────────────────────┤
│  framework/                                                  │
│  ├─ Machine (DI 容器, 读 yaml → 创建平台实例)                │
│  ├─ ModuleManager (模块加载/生命周期/60Hz 主循环)            │
│  ├─ EventBus (类型键控发布/订阅, RLock, 1000 条历史)         │
│  ├─ StateMachine Engine (BaseStateMachine + Bridge)           │
│  └─ VisualStateMachine (5 状态视觉追踪)                       │
├─────────────────────────────────────────────────────────────┤
│  modules/                                                    │
│  ├─ zw_opencv_module                                         │
│  │  └─ VisionManager (后台线程)                              │
│  │     └─ PipelineCamera (摄像头管道)                        │
│  │        └─ TaskManager (串行执行 Processors)               │
│  └─ zw_uart_module                                           │
│     └─ STM32UartInterface (HAL Uart + FrameParser 状态机)    │
├─────────────────────────────────────────────────────────────┤
│  framework/hal/                                              │
│  ├─ interface/ (Protocol 定义)                                │
│  └─ platforms/{maixcam2, linux, mock}/ (实现)                │
└─────────────────────────────────────────────────────────────┘
```

### 3.2 线程模型

| 线程 | 所属 | 频率 | CPU 核心 | 用途 |
|------|------|------|---------|------|
| 主循环 | ModuleManager | ~60Hz | core 0 | 模块 loop(), coordinator.loop(), display, 看门狗喂狗 |
| 视觉处理 | VisionManager (daemon) | 依赖 FPS | core 1 | capture → image2cv → 任务串行 → pending_results |
| 心跳 | LineFollowCoordinator (daemon) | 100ms | core 0 | 发送心跳帧, 检查链接超时 (300ms) |
| UART 接收 | maix.peripheral.uart (回调) | 硬件中断 | — | 字节接收 → FrameParser → EventBus |
| 调试控制台 | DebugConsole (2× daemon) | 10 FPS | core 0 | 渲染 Rich TUI, 按键监听 'q' 退出 |

### 3.3 数据流

```
camera.read_raw()                    [视觉线程]
  → maix.image.image2cv()
  → TaskManager.run_tasks_serial()   [串行执行 Processors]
  → VisionManager._pending_results   [deque, maxlen=5]
       ↓ drain_results()             [主线程, coordinator.loop()]
  → _process_vision_results()
    ├─ line_follow → build_visual_servo_data_frame → uart.send_raw()
    └─ ai_inference → 计数统计
       ↓
  → state_machine.run_to_completion()

uart.set_received_callback()          [UART 回调线程]
  → FrameParser.feed() → parse_frame()
  → EventBus.publish(HeartbeatEvent/EmergencyStopEvent)
       ↓ 订阅者
  → coordinator._on_heartbeat() / _on_emergency()
  → _enqueue_sm(lambda)               [线程安全入队]
       ↓ 主线程 drain
  → state_machine.trigger(event)
```

---

## 4. 关键技术细节

### 4.1 平台抽象 (HAL)

所有平台必须提供工厂函数:
| 函数 | 返回类型 | maixcam2 实现 | linux 实现 |
|------|---------|---------------|-----------|
| `create_camera(source, w, h, **kw)` | `Camera` | `maix.camera.Camera` + `image2cv` | `cv2.VideoCapture` + warmup |
| `create_display()` | `Display` | `maix.display.Display` | `cv2.imshow` |
| `create_uart(port, baudrate)` | `Uart` | `maix.peripheral.uart`(回调) | `pyserial` + 轮询线程 |
| `create_ai()` | `AIInference` | `maix.nn.YOLO11/Classifier/HandLandmarks` | 存根(无 NPU) |

### 4.2 AI 推理 (maixcam2)

- **模型注册表**: `MaixCam2AI._registry` — 按 nick_name 存储 `{path, type, kwargs}`
- **多模型支持**: 通过 `_SLOT_CLASSES` 映射: `"yolo"→YOLO11`, `"classifier"→Classifier`, `"hand_landmarks"→HandLandmarks`, `"nn"→NN`
- **`switch(nick_name)`**: 卸载当前 → 加载新模型 (`dual_buff=True`)
- **`detect()`**: 接受 BGR numpy (标准) 或 `maix.image.Image` (零拷贝, `_raw=True`)
- **Keypoints 解析**: 根据 model_type 自动检测 step=2 或 step=3; hand_landmarks 特殊处理
- **分割掩膜**: 支持 `find_blobs`/`numpy`/`none` 三种分析方法
- 详见 `framework/hal/platforms/maixcam2/ai.py`

### 4.3 UART 协议 v2.1

```
帧结构: | SOF1(0xAA) | SOF2(0x55) | Length | Type | Payload(0-252) | CRC16_HI | CRC16_LO |
```
- **CRC16**: CCITT, poly 0x1021, init 0xFFFF, 查表, 无反射, 无最终 XOR
- **帧类型**: `TYPE_ERROR(0x01)`, `TYPE_HEARTBEAT(0x15)`, `TYPE_VISUAL_SERVO_DATA(0x17)`, `TYPE_EMERGENCY_STOP(0x18)`
- **解析状态机**: `WAITING_SOF → GOT_SOF1 → GOT_SOF → GOT_LEN`
  - `WAITING_SOF`: 寻找 0xAA
  - `GOT_SOF1`: 期待 0x55, 遇到 0xAA 则重新锚定 (抗噪声)
  - `GOT_SOF`: 读 Length, 验证 3≤len≤255
  - `GOT_LEN`: 累积 payload + CRC, 调用 protocol.parse_frame
- 详见 `modules/zw_uart_module/protocol.py`, `uart_driver.py`

### 4.4 状态机引擎 (BaseStateMachine)

- **线程安全**: `threading.RLock` 保护所有状态变更
- **两种转换机制**:
  1. **自驱动**: `State.on_execute()` 返回目标状态名
  2. **事件驱动**: `trigger(event)` → 查 `_event_transitions[当前状态][事件]`
- **级联保护**: `run_to_completion(max_steps=10)` 防止死循环
- **回调三层级**: 全局 `_state_callbacks` + per-state enter/exit callbacks
- 详见 `framework/state_machine/base.py`

### 4.5 34 状态竞赛状态机

- **MissionState (0-19)**: IDLE, WAIT_START, READ_QR, NAV_TO_RAW, ALIGN_RAW, PICK_RAW, CHECK_LOAD, NAV_TO_ROUGH, ALIGN_ROUGH, PLACE_ROUGH, PICK_ROUGH, NAV_TO_TEMP, ALIGN_TEMP, PLACE_TEMP, NAV_TO_RAW_SECOND, RETURN_HOME, FINISHED, ERROR, RING_DISCOVERY, CARGO_DISCOVERY
- **批次逻辑**: QR 解析 "123+231" → first_batch_order / second_batch_order; 两轮运输
- **颜色追踪**: `CargoSet` 管理 6 个物料; `current_target_color()` 获取当前目标
- **超时机制**: ALIGN 360s, CHECK_LOAD 3s, RING/CARGO_DISCOVERY 360s
- 详见 `app/mission_state_machine.py`

### 4.6 心跳 + 链接保活

- `LineFollowCoordinator._heartbeat_thread`: daemon, 100ms 间隔
- MCU 必须在 300ms 内回复心跳, 否则 `_is_linked = False`
- 心跳帧包含: `seq(0-255)`, `mission_state`, `visual_state`
- 看门狗: `maix.peripheral.wdt.WDT(timeout=3000)`, 每 tick 喂狗

### 4.7 CPU 亲和性 (仅 Linux)

```python
_role_core_map = {
    "vision_processing": {1},  # 大核
    "camera_capture":    {0},  # 小核
    "main_loop":         {0},
    "heartbeat":         {0},
    "uart_receiver":     {0},
    "debug_console":     {0},
}
```
使用 `os.sched_setaffinity(0, cores)`; 非 Linux 平台静默无操作。

---

## 5. 配置文件

### `project_config.yaml`
```yaml
platform: maixcam2
display_enabled: true
cameras:
  - camera_id: "main"
    source: null           # maixcam2 板载摄像头, 无需指定
    width: 640
    height: 640
uart_defaults:
  port: "/dev/ttyS3"
  baudrate: 115200
ai:
  models:
    - nick_name: "yolo11n"
      model: "/root/models/steelball_640.mud"
      model_type: "auto"   # auto → maix.nn.YOLO11
  active: "yolo11n"
```

### `vision_config.yaml` (zw_opencv_module 内部)
```yaml
pipelines:
  - pipeline_id: "cam_main"
    camera_id: "main"
    tasks:
      - name: "ai_inference"
        type: "AIInferenceProcessor"
        enabled: true
      - name: "line_follow"
        type: "LineFollowProcessor"
        enabled: false       # 在循迹阶段动态启用
```

### `app.yaml` (MaixPy 应用打包)
- ID: `zulu_walker`, version 1.0.0
- Exclude 了 `.git`, `.vscode`, `.claude`, `stories`, `docs`, `requirements*`, 以及多个已弃用的 processors/detectors

---

## 6. 已知陷阱 & 历史问题

### 已修复 ✅
- **CHECK_LOAD cargo_confirmed 死锁**: `VisualFlags.CARGO_CONFIRMED(0x20)` 从未被设置; 已改为直接跳过检测
- **build_visual_servo_data_frame float→int**: 统一输出 `int[-5000, 5000]`
- **OpenCL 分散调用**: 集中到 `CameraManager.__init__`
- **未使用 VisualFlags**: `QR_OK(0x10)`, `VISUAL_FAIL(0x08)`, `COLOR_MISMATCH(0x40)` 定义了但无代码设置

### 🚧 PICK_RAW 转盘策略 (讨论中)
- 原料区转盘 6-10s/圈, 物料 120° 间隔, 平移式机械臂无法横向避让
- 方案: 固定 ROI 监测夹爪下方, 匹配 `current_target_color()` 则触发抓取
- 开放问题: 是否打破 QR 顺序? 是否改协议加打断/收回信号?

### ⚠️ 内核 HZ 限制
- 当前 ~300Hz (`MAIN_LOOP_DELAY=0.00333`)
- 目标 `HZ=1000` + `CONFIG_HIGH_RES_TIMERS=y` 后可降至 0.001
- 需要换内核, 暂时不做

### ⚠️ 状态名 vs 状态 ID 混淆
- `MissionStateNames` 是 `Dict[int, str]` (如 `{0: "IDLE", 5: "PICK_RAW"}`)
- `on_execute()` 必须返回**状态名字符串** (如 `"PICK_RAW"`), 不是整数 ID
- 历史: 8 个状态类曾误用 `MissionStateNames.PICK_RAW` (点号访问 dict) 导致 `AttributeError`

---

## 7. 已弃用/已过时代码

- `modules/zw_opencv_module/processors/` 中多个处理器 (`cargo_processor`, `circle_target_processor`, `ring_discovery_processor`, `qr_processor`, `ai_inference_processor`) 已被 `app.yaml` exclude, 但代码仍保留
- `docs/migration_plan.md` 描述的 Orange Pi 5B → MaixCAM2 迁移方案已基本完成, 细节可能滞后
- `docs/pitfalls/vision_data_flow.md` 描述的问题已通过 `_pending_results` deque + `drain_results()` 模式解决, 文中 `EventBus.FrameResult` 事件已不再使用

---

## 8. MaixPy 内部 API 参考

`MaixPy-main/` 是上游 Sipeed MaixPy 固件的完整源码克隆。`maix.*` 模块定义在固件 C++ 层, 通过 `pybind11` 绑定导出。

| 本项目中使用的 maix.* 模块 | 用途 | MaixPy-main 参考位置 |
|---------------------------|------|---------------------|
| `maix.camera.Camera` | 摄像头读取 | `components/maix/src/maixpy.cpp` (绑定) |
| `maix.display.Display` | 显示输出 | `components/maix/src/maixpy.cpp` |
| `maix.peripheral.uart.UART` | UART 通信 | `projects/` 中搜索 uart 使用示例 |
| `maix.nn.YOLO11` | YOLO 推理 | `components/maix/include/maixpy.hpp` |
| `maix.nn.NN` | 通用 NN 推理 | 同上 |
| `maix.nn.Classifier` | 分类器 | 同上 |
| `maix.nn.HandLandmarks` | 手部关键点 | 同上 |
| `maix.image.image2cv()` | 图像转换 | `components/maix/include/convert_image.hpp` |
| `maix.image.cv2image()` | 图像转换 | 同上 |
| `maix.sys` | 系统信息/内存 | `maix/__init__.py` |
| `maix.peripheral.wdt` | 看门狗 | `components/maix/src/maixpy.cpp` |

---

## 9. 开发命令

```bash
# 运行主程序
python run.py main

# 调试调试器
python run.py debug cargo             # 物料块检测
python run.py debug circle            # 圆靶检测
python run.py debug ring              # 环检测
python run.py debug line              # 黑线循迹
python run.py debug [name] -c 1 -W 1280 -H 720  # 指定摄像头/分辨率

# Windows 编译检查
python -c "import py_compile; py_compile.compile('app/main.py', doraise=True)"
python -c "import py_compile; py_compile.compile('framework/hal/machine.py', doraise=True)"

# 导入检查
python -c "from framework.hal import Machine; print('OK')"
python -c "from modules.zw_uart_module import STM32UartInterface, FrameParser; print('OK')"
python -c "from modules.zw_opencv_module.vision_manager import VisionManager; print('OK')"
```

---

## 10. 关键文件摘要

| 文件 | 行数 | 作用 |
|------|------|------|
| `app/main.py` | 125 | 应用入口, DI, 主循环 |
| `app/coordinator.py` | 222 | 桥接视觉→UART, 心跳协议 |
| `app/mission_state_machine.py` | 931 | 34 状态竞赛状态机 |
| `app/line_follow_sm.py` | 169 | 5 状态简单循迹 SM |
| `framework/hal/machine.py` | 143 | DI 容器, 读 yaml 创建平台实例 |
| `framework/hal/platforms/maixcam2/ai.py` | 434 | MaixPy AI 推理 (核心) |
| `framework/state_machine/base.py` | 412 | 通用状态机引擎 |
| `framework/visual_state_machine.py` | 264 | 视觉追踪 SM |
| `framework/module_manager.py` | 112 | 模块生命周期 + 60Hz 主循环 |
| `framework/event_bus.py` | 44 | 发布/订阅事件总线 |
| `framework/hal/platforms/linux/camera.py` | 324 | Linux 相机 (warmup+重连) |
| `modules/zw_uart_module/uart_driver.py` | 428 | UART FrameParser 状态机 |
| `modules/zw_uart_module/protocol.py` | 181 | 协议 v2.1 定义+CRC16 |
| `modules/zw_opencv_module/vision_manager.py` | 382 | 视觉管道管理器+后台线程 |
| `modules/zw_opencv_module/task_manager.py` | 168 | 串行任务执行 |
| `utils/debug_console.py` | 205 | Rich TUI 调试控制台 |
| `utils/cpu_affinity.py` | 95 | CPU 亲和性配置 |
| `utils/camera_misc_util.py` | 275 | V4L2 摄像头发现 |
| `utils/log_util.py` | 237 | 日志工厂 + 文件日志 |

---

## 已知待改善 (Known Issues)

1. **SegmentationHandler 孤儿化** — `segmentation.py` 注册 key 为 `"yolo_seg"`，但 `project_config.yaml` 中 seg 模型用 `model_type: "auto"`，handler 查找 fallback 到 DefaultHandler。cv2 离线帧不会叠加 seg mask 彩色填充。修复：将 `plate_seg` 的 `model_type` 改为 `"yolo_seg"` 或修改 handler 注册/查找逻辑。

2. **LCD 端 seg mask 半透明叠加丢失** — `_update_display_frame` 已改为复用 `pipe.last_results` 缓存（commit 5909600，NPU 2→1 次/帧），不再调 `detect()` 内的 `draw_seg_mask`。LCD 仅显示 bbox + 标签 + mask 中心红点。若需恢复半透明叠加，可在 Detection 中携带原始 `maix.image` 引用供 display 线程调用 `model.draw_seg_mask()`。
